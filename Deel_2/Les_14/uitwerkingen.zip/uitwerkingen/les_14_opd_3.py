fruitlijst = ["appel" , "peer" , "banaan" , "mandarijn" , "kiwi" , "ananas" , "citroen" , "limoen"]
fruitlijst.remove(input("noem een fruitsoort "))

print(fruitlijst)

    