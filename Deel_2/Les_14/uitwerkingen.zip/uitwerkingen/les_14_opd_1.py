lijst = []
lijst.append(input("vul een paar cijfer in "))

print(lijst)