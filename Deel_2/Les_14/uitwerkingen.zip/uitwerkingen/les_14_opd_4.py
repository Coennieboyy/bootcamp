woordlijst = []

for x in range(5):
    woord = (input("voer een woord in. "))
    woordlijst.append(woord)

print("de ingevoerde woorden zijn")

for woord in woordlijst:
    print(woord)

 