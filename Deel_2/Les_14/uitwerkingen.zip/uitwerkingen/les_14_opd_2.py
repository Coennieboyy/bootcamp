lijst = ["1" , "2" , "3" , "4" , "5"]
lijst.pop(int(input("noem een cijfer onder de 5 ")))

print(lijst)